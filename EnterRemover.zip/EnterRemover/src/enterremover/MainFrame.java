package enterremover;

import com.formdev.flatlaf.IntelliJTheme;
import java.awt.AWTException;
import java.awt.Robot;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyEvent;
import javax.swing.Timer;

public class MainFrame extends javax.swing.JFrame {
    
    Robot r;
    
    public MainFrame() {
        initComponents();
        
        try {
            r = new Robot();
        } catch (AWTException ex) {
            ex.printStackTrace();
        }
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        jScrollPane1 = new javax.swing.JScrollPane();
        txtOutput = new javax.swing.JTextArea();
        jScrollPane2 = new javax.swing.JScrollPane();
        txtInput = new javax.swing.JTextArea();
        btnHapusEnter = new javax.swing.JButton();
        txtKeterangan = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setMaximumSize(new java.awt.Dimension(759, 480));
        setMinimumSize(new java.awt.Dimension(759, 480));
        setPreferredSize(new java.awt.Dimension(759, 480));
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jPanel1.setMaximumSize(new java.awt.Dimension(756, 412));
        jPanel1.setMinimumSize(new java.awt.Dimension(756, 412));
        jPanel1.setPreferredSize(new java.awt.Dimension(756, 412));
        jPanel1.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel1.setFont(new java.awt.Font("Segoe UI", 1, 24)); // NOI18N
        jLabel1.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel1.setText("ENTER REMOVER");
        jPanel1.add(jLabel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 756, 89));

        txtOutput.setEditable(false);
        txtOutput.setColumns(20);
        txtOutput.setFont(new java.awt.Font("Segoe UI", 0, 12)); // NOI18N
        txtOutput.setRows(5);
        txtOutput.setText("hasil penghapusan disini...");
        txtOutput.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                txtOutputMouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                txtOutputMouseExited(evt);
            }
        });
        jScrollPane1.setViewportView(txtOutput);

        jPanel1.add(jScrollPane1, new org.netbeans.lib.awtextra.AbsoluteConstraints(50, 260, 670, 120));

        txtInput.setColumns(20);
        txtInput.setFont(new java.awt.Font("Segoe UI", 0, 12)); // NOI18N
        txtInput.setRows(5);
        txtInput.setText("masukan text disini...");
        txtInput.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusGained(java.awt.event.FocusEvent evt) {
                txtInputFocusGained(evt);
            }
            public void focusLost(java.awt.event.FocusEvent evt) {
                txtInputFocusLost(evt);
            }
        });
        txtInput.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                txtInputMouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                txtInputMouseExited(evt);
            }
        });
        jScrollPane2.setViewportView(txtInput);

        jPanel1.add(jScrollPane2, new org.netbeans.lib.awtextra.AbsoluteConstraints(50, 90, 670, 110));

        btnHapusEnter.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        btnHapusEnter.setText("HAPUS ENTER");
        btnHapusEnter.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnHapusEnterActionPerformed(evt);
            }
        });
        jPanel1.add(btnHapusEnter, new org.netbeans.lib.awtextra.AbsoluteConstraints(50, 210, 670, 40));

        txtKeterangan.setBackground(new java.awt.Color(245, 121, 0));
        txtKeterangan.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        txtKeterangan.setForeground(new java.awt.Color(245, 121, 0));
        jPanel1.add(txtKeterangan, new org.netbeans.lib.awtextra.AbsoluteConstraints(50, 380, 270, 20));

        getContentPane().add(jPanel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 760, 410));

        pack();
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    private void txtInputMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_txtInputMouseEntered
        if(txtInput.getText().equals("masukan text disini...")) {
            txtInput.setText("");
        }
    }//GEN-LAST:event_txtInputMouseEntered

    private void txtInputMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_txtInputMouseExited
        if(txtInput.getText().equals("")) {
            txtInput.setText("masukan text disini...");
        }
    }//GEN-LAST:event_txtInputMouseExited

    private void txtInputFocusGained(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_txtInputFocusGained
        if(txtInput.getText().equals("masukan text disini...")) {
            txtInput.setText("");
        }
    }//GEN-LAST:event_txtInputFocusGained

    private void txtInputFocusLost(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_txtInputFocusLost
        if(txtInput.getText().equals("")) {
            txtInput.setText("masukan text disini...");
        }
    }//GEN-LAST:event_txtInputFocusLost

    private void txtOutputMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_txtOutputMouseEntered
        if(txtOutput.getText().equals("hasil penghapusan disini...")) {
            txtOutput.setText("");
        }
    }//GEN-LAST:event_txtOutputMouseEntered

    private void txtOutputMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_txtOutputMouseExited
        if(txtOutput.getText().equals("")) {
            txtOutput.setText("hasil penghapusan disini...");
        }
    }//GEN-LAST:event_txtOutputMouseExited

    int waktuTerlewat = 0;
    private void btnHapusEnterActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnHapusEnterActionPerformed
        String input = txtInput.getText();
        txtOutput.setText(input.replaceAll("\n", " ").replaceAll("  ", " "));
        txtOutput.requestFocus();
        
        r.keyPress(KeyEvent.VK_CONTROL);
        
        r.keyPress(KeyEvent.VK_A);
        r.keyRelease(KeyEvent.VK_A);
        
        r.keyPress(KeyEvent.VK_C);
        r.keyRelease(KeyEvent.VK_C);
        
        r.keyRelease(KeyEvent.VK_CONTROL);
        
        txtKeterangan.setText("Text berhasil dicopy.!");
        btnHapusEnter.setEnabled(false);
        ActionListener taskPerformer = new ActionListener() {

            @Override
            public void actionPerformed(ActionEvent evt) {
                waktuTerlewat++;
                System.out.println("Waktu : "+ waktuTerlewat);
                if(waktuTerlewat == 2) {
                    ((Timer)(evt.getSource())).stop();
                    txtKeterangan.setText("");
                    btnHapusEnter.setEnabled(true);
                }
            }
        };
        new Timer(1000, taskPerformer).start();
    }//GEN-LAST:event_btnHapusEnterActionPerformed

    public static void main(String args[]) {
        try {
            IntelliJTheme.setup(MainFrame.class.
                getResourceAsStream("/enterremover/json/arc-dark-orange.theme.json"));
        } catch (Exception e) {
            e.printStackTrace();
        }
        
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new MainFrame().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnHapusEnter;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JTextArea txtInput;
    private javax.swing.JLabel txtKeterangan;
    private javax.swing.JTextArea txtOutput;
    // End of variables declaration//GEN-END:variables
}
